from django.contrib import admin
from django.urls import include, path
from django.conf import settings
from django.conf.urls.static import static

from meu_app import views


urlpatterns = [
    path('', views.painel_equipamentos, name='dashboard'),
    path('admin/', admin.site.urls),
    path('__reload__/', include('django_browser_reload.urls')),
    path('dashboard/', views.painel_equipamentos, name='dashboard'),
    path('cadastrar/', views.cadastrar_equipamento, name='cadastrar_equipamento'),
    path('equipamento/<int:id>/', views.detalhe_equipamento, name='detalhe_equipamento'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
