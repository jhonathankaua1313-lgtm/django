from django.shortcuts import get_object_or_404, redirect, render

from .forms import EquipamentoForm
from .models import Equipamento


def painel_equipamentos(request):
    equipamentos = Equipamento.objects.all()

    bandeja = {
        'equipamentos': equipamentos,
        'total': equipamentos.count(),
    }

    return render(request, 'meu_app/dashboard.html', bandeja)


def cadastrar_equipamento(request):
    if request.method == 'POST':
        form = EquipamentoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('dashboard')
    else:
        form = EquipamentoForm()

    return render(request, 'meu_app/cadastrar_equipamento.html', {'form': form})


def detalhe_equipamento(request, id):
    equipamento = get_object_or_404(Equipamento, id=id)

    bandeja = {
        'equipamento': equipamento,
    }

    return render(request, 'meu_app/detalhe_equipamento.html', bandeja)
